"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "app/api/index/[id]/route";
exports.ids = ["app/api/index/[id]/route"];
exports.modules = {

/***/ "next/dist/compiled/next-server/app-page.runtime.dev.js":
/*!*************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-page.runtime.dev.js" ***!
  \*************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-page.runtime.dev.js");

/***/ }),

/***/ "next/dist/compiled/next-server/app-route.runtime.dev.js":
/*!**************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-route.runtime.dev.js" ***!
  \**************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-route.runtime.dev.js");

/***/ }),

/***/ "undici":
/*!*************************!*\
  !*** external "undici" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("undici");

/***/ }),

/***/ "assert":
/*!*************************!*\
  !*** external "assert" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("assert");

/***/ }),

/***/ "buffer":
/*!*************************!*\
  !*** external "buffer" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("buffer");

/***/ }),

/***/ "events":
/*!*************************!*\
  !*** external "events" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("events");

/***/ }),

/***/ "http":
/*!***********************!*\
  !*** external "http" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("http");

/***/ }),

/***/ "https":
/*!************************!*\
  !*** external "https" ***!
  \************************/
/***/ ((module) => {

module.exports = require("https");

/***/ }),

/***/ "node:timers/promises":
/*!***************************************!*\
  !*** external "node:timers/promises" ***!
  \***************************************/
/***/ ((module) => {

module.exports = require("node:timers/promises");

/***/ }),

/***/ "os":
/*!*********************!*\
  !*** external "os" ***!
  \*********************/
/***/ ((module) => {

module.exports = require("os");

/***/ }),

/***/ "querystring":
/*!******************************!*\
  !*** external "querystring" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("querystring");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("stream");

/***/ }),

/***/ "timers/promises":
/*!**********************************!*\
  !*** external "timers/promises" ***!
  \**********************************/
/***/ ((module) => {

module.exports = require("timers/promises");

/***/ }),

/***/ "tty":
/*!**********************!*\
  !*** external "tty" ***!
  \**********************/
/***/ ((module) => {

module.exports = require("tty");

/***/ }),

/***/ "url":
/*!**********************!*\
  !*** external "url" ***!
  \**********************/
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("util");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("zlib");

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Findex%2F%5Bid%5D%2Froute&page=%2Fapi%2Findex%2F%5Bid%5D%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Findex%2F%5Bid%5D%2Froute.js&appDir=C%3A%5CUsers%5Camanm%5COneDrive%5CDesktop%5Ccldshp%20-%20Projects%5CCRUD-NEXTJS-ELASTIC--copy%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5Camanm%5COneDrive%5CDesktop%5Ccldshp%20-%20Projects%5CCRUD-NEXTJS-ELASTIC--copy&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!":
/*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Findex%2F%5Bid%5D%2Froute&page=%2Fapi%2Findex%2F%5Bid%5D%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Findex%2F%5Bid%5D%2Froute.js&appDir=C%3A%5CUsers%5Camanm%5COneDrive%5CDesktop%5Ccldshp%20-%20Projects%5CCRUD-NEXTJS-ELASTIC--copy%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5Camanm%5COneDrive%5CDesktop%5Ccldshp%20-%20Projects%5CCRUD-NEXTJS-ELASTIC--copy&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D! ***!
  \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   originalPathname: () => (/* binding */ originalPathname),\n/* harmony export */   patchFetch: () => (/* binding */ patchFetch),\n/* harmony export */   requestAsyncStorage: () => (/* binding */ requestAsyncStorage),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   serverHooks: () => (/* binding */ serverHooks),\n/* harmony export */   staticGenerationAsyncStorage: () => (/* binding */ staticGenerationAsyncStorage)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/future/route-modules/app-route/module.compiled */ \"(rsc)/./node_modules/next/dist/server/future/route-modules/app-route/module.compiled.js\");\n/* harmony import */ var next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/future/route-kind */ \"(rsc)/./node_modules/next/dist/server/future/route-kind.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/server/lib/patch-fetch */ \"(rsc)/./node_modules/next/dist/server/lib/patch-fetch.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var C_Users_amanm_OneDrive_Desktop_cldshp_Projects_CRUD_NEXTJS_ELASTIC_copy_app_api_index_id_route_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app/api/index/[id]/route.js */ \"(rsc)/./app/api/index/[id]/route.js\");\n\n\n\n\n// We inject the nextConfigOutput here so that we can use them in the route\n// module.\nconst nextConfigOutput = \"\"\nconst routeModule = new next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({\n    definition: {\n        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,\n        page: \"/api/index/[id]/route\",\n        pathname: \"/api/index/[id]\",\n        filename: \"route\",\n        bundlePath: \"app/api/index/[id]/route\"\n    },\n    resolvedPagePath: \"C:\\\\Users\\\\amanm\\\\OneDrive\\\\Desktop\\\\cldshp - Projects\\\\CRUD-NEXTJS-ELASTIC--copy\\\\app\\\\api\\\\index\\\\[id]\\\\route.js\",\n    nextConfigOutput,\n    userland: C_Users_amanm_OneDrive_Desktop_cldshp_Projects_CRUD_NEXTJS_ELASTIC_copy_app_api_index_id_route_js__WEBPACK_IMPORTED_MODULE_3__\n});\n// Pull out the exports that we need to expose from the module. This should\n// be eliminated when we've moved the other routes to the new format. These\n// are used to hook into the route.\nconst { requestAsyncStorage, staticGenerationAsyncStorage, serverHooks } = routeModule;\nconst originalPathname = \"/api/index/[id]/route\";\nfunction patchFetch() {\n    return (0,next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__.patchFetch)({\n        serverHooks,\n        staticGenerationAsyncStorage\n    });\n}\n\n\n//# sourceMappingURL=app-route.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWFwcC1sb2FkZXIuanM/bmFtZT1hcHAlMkZhcGklMkZpbmRleCUyRiU1QmlkJTVEJTJGcm91dGUmcGFnZT0lMkZhcGklMkZpbmRleCUyRiU1QmlkJTVEJTJGcm91dGUmYXBwUGF0aHM9JnBhZ2VQYXRoPXByaXZhdGUtbmV4dC1hcHAtZGlyJTJGYXBpJTJGaW5kZXglMkYlNUJpZCU1RCUyRnJvdXRlLmpzJmFwcERpcj1DJTNBJTVDVXNlcnMlNUNhbWFubSU1Q09uZURyaXZlJTVDRGVza3RvcCU1Q2NsZHNocCUyMC0lMjBQcm9qZWN0cyU1Q0NSVUQtTkVYVEpTLUVMQVNUSUMtLWNvcHklNUNhcHAmcGFnZUV4dGVuc2lvbnM9dHN4JnBhZ2VFeHRlbnNpb25zPXRzJnBhZ2VFeHRlbnNpb25zPWpzeCZwYWdlRXh0ZW5zaW9ucz1qcyZyb290RGlyPUMlM0ElNUNVc2VycyU1Q2FtYW5tJTVDT25lRHJpdmUlNUNEZXNrdG9wJTVDY2xkc2hwJTIwLSUyMFByb2plY3RzJTVDQ1JVRC1ORVhUSlMtRUxBU1RJQy0tY29weSZpc0Rldj10cnVlJnRzY29uZmlnUGF0aD10c2NvbmZpZy5qc29uJmJhc2VQYXRoPSZhc3NldFByZWZpeD0mbmV4dENvbmZpZ091dHB1dD0mcHJlZmVycmVkUmVnaW9uPSZtaWRkbGV3YXJlQ29uZmlnPWUzMCUzRCEiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0FBQXNHO0FBQ3ZDO0FBQ2M7QUFDa0U7QUFDL0k7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLGdIQUFtQjtBQUMzQztBQUNBLGNBQWMseUVBQVM7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLFlBQVk7QUFDWixDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0EsUUFBUSxpRUFBaUU7QUFDekU7QUFDQTtBQUNBLFdBQVcsNEVBQVc7QUFDdEI7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUN1SDs7QUFFdkgiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jcnVkXzIvP2RlOGQiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQXBwUm91dGVSb3V0ZU1vZHVsZSB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL2Z1dHVyZS9yb3V0ZS1tb2R1bGVzL2FwcC1yb3V0ZS9tb2R1bGUuY29tcGlsZWRcIjtcbmltcG9ydCB7IFJvdXRlS2luZCB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL2Z1dHVyZS9yb3V0ZS1raW5kXCI7XG5pbXBvcnQgeyBwYXRjaEZldGNoIGFzIF9wYXRjaEZldGNoIH0gZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvbGliL3BhdGNoLWZldGNoXCI7XG5pbXBvcnQgKiBhcyB1c2VybGFuZCBmcm9tIFwiQzpcXFxcVXNlcnNcXFxcYW1hbm1cXFxcT25lRHJpdmVcXFxcRGVza3RvcFxcXFxjbGRzaHAgLSBQcm9qZWN0c1xcXFxDUlVELU5FWFRKUy1FTEFTVElDLS1jb3B5XFxcXGFwcFxcXFxhcGlcXFxcaW5kZXhcXFxcW2lkXVxcXFxyb3V0ZS5qc1wiO1xuLy8gV2UgaW5qZWN0IHRoZSBuZXh0Q29uZmlnT3V0cHV0IGhlcmUgc28gdGhhdCB3ZSBjYW4gdXNlIHRoZW0gaW4gdGhlIHJvdXRlXG4vLyBtb2R1bGUuXG5jb25zdCBuZXh0Q29uZmlnT3V0cHV0ID0gXCJcIlxuY29uc3Qgcm91dGVNb2R1bGUgPSBuZXcgQXBwUm91dGVSb3V0ZU1vZHVsZSh7XG4gICAgZGVmaW5pdGlvbjoge1xuICAgICAgICBraW5kOiBSb3V0ZUtpbmQuQVBQX1JPVVRFLFxuICAgICAgICBwYWdlOiBcIi9hcGkvaW5kZXgvW2lkXS9yb3V0ZVwiLFxuICAgICAgICBwYXRobmFtZTogXCIvYXBpL2luZGV4L1tpZF1cIixcbiAgICAgICAgZmlsZW5hbWU6IFwicm91dGVcIixcbiAgICAgICAgYnVuZGxlUGF0aDogXCJhcHAvYXBpL2luZGV4L1tpZF0vcm91dGVcIlxuICAgIH0sXG4gICAgcmVzb2x2ZWRQYWdlUGF0aDogXCJDOlxcXFxVc2Vyc1xcXFxhbWFubVxcXFxPbmVEcml2ZVxcXFxEZXNrdG9wXFxcXGNsZHNocCAtIFByb2plY3RzXFxcXENSVUQtTkVYVEpTLUVMQVNUSUMtLWNvcHlcXFxcYXBwXFxcXGFwaVxcXFxpbmRleFxcXFxbaWRdXFxcXHJvdXRlLmpzXCIsXG4gICAgbmV4dENvbmZpZ091dHB1dCxcbiAgICB1c2VybGFuZFxufSk7XG4vLyBQdWxsIG91dCB0aGUgZXhwb3J0cyB0aGF0IHdlIG5lZWQgdG8gZXhwb3NlIGZyb20gdGhlIG1vZHVsZS4gVGhpcyBzaG91bGRcbi8vIGJlIGVsaW1pbmF0ZWQgd2hlbiB3ZSd2ZSBtb3ZlZCB0aGUgb3RoZXIgcm91dGVzIHRvIHRoZSBuZXcgZm9ybWF0LiBUaGVzZVxuLy8gYXJlIHVzZWQgdG8gaG9vayBpbnRvIHRoZSByb3V0ZS5cbmNvbnN0IHsgcmVxdWVzdEFzeW5jU3RvcmFnZSwgc3RhdGljR2VuZXJhdGlvbkFzeW5jU3RvcmFnZSwgc2VydmVySG9va3MgfSA9IHJvdXRlTW9kdWxlO1xuY29uc3Qgb3JpZ2luYWxQYXRobmFtZSA9IFwiL2FwaS9pbmRleC9baWRdL3JvdXRlXCI7XG5mdW5jdGlvbiBwYXRjaEZldGNoKCkge1xuICAgIHJldHVybiBfcGF0Y2hGZXRjaCh7XG4gICAgICAgIHNlcnZlckhvb2tzLFxuICAgICAgICBzdGF0aWNHZW5lcmF0aW9uQXN5bmNTdG9yYWdlXG4gICAgfSk7XG59XG5leHBvcnQgeyByb3V0ZU1vZHVsZSwgcmVxdWVzdEFzeW5jU3RvcmFnZSwgc3RhdGljR2VuZXJhdGlvbkFzeW5jU3RvcmFnZSwgc2VydmVySG9va3MsIG9yaWdpbmFsUGF0aG5hbWUsIHBhdGNoRmV0Y2gsICB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1hcHAtcm91dGUuanMubWFwIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Findex%2F%5Bid%5D%2Froute&page=%2Fapi%2Findex%2F%5Bid%5D%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Findex%2F%5Bid%5D%2Froute.js&appDir=C%3A%5CUsers%5Camanm%5COneDrive%5CDesktop%5Ccldshp%20-%20Projects%5CCRUD-NEXTJS-ELASTIC--copy%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5Camanm%5COneDrive%5CDesktop%5Ccldshp%20-%20Projects%5CCRUD-NEXTJS-ELASTIC--copy&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!\n");

/***/ }),

/***/ "(rsc)/./app/api/index/[id]/route.js":
/*!*************************************!*\
  !*** ./app/api/index/[id]/route.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   DELETE: () => (/* binding */ DELETE),\n/* harmony export */   GET: () => (/* binding */ GET),\n/* harmony export */   PUT: () => (/* binding */ PUT)\n/* harmony export */ });\n/* harmony import */ var _app_lib_elastic__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/app/lib/elastic */ \"(rsc)/./app/lib/elastic.js\");\n/* harmony import */ var next_server__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/server */ \"(rsc)/./node_modules/next/dist/api/server.js\");\n\n\nasync function GET(request, { params }) {\n    const _id = params.id;\n    const updateInfo = await _app_lib_elastic__WEBPACK_IMPORTED_MODULE_0__[\"default\"].get({\n        index: \"cms-aman\",\n        id: _id\n    });\n    return next_server__WEBPACK_IMPORTED_MODULE_1__.NextResponse.json(updateInfo._source);\n}\nasync function PUT(request, { params }) {\n    try {\n        const _id = params.id;\n        const { name, mobno } = await request.json();\n        const updateData = await _app_lib_elastic__WEBPACK_IMPORTED_MODULE_0__[\"default\"].update({\n            index: \"cms-aman\",\n            id: _id,\n            body: {\n                doc: {\n                    name,\n                    mobno\n                }\n            }\n        });\n        return next_server__WEBPACK_IMPORTED_MODULE_1__.NextResponse.json(updateData);\n    } catch (error) {\n        return next_server__WEBPACK_IMPORTED_MODULE_1__.NextResponse.json({\n            message: \"error occur in Updating Details\"\n        }, {\n            status: 500\n        });\n    }\n}\nasync function DELETE(request, { params }) {\n    try {\n        const _id = params.id;\n        const deleteData = await _app_lib_elastic__WEBPACK_IMPORTED_MODULE_0__[\"default\"].delete({\n            index: \"cms-aman\",\n            id: _id\n        });\n        return next_server__WEBPACK_IMPORTED_MODULE_1__.NextResponse.json(deleteData);\n    } catch (error) {\n        return next_server__WEBPACK_IMPORTED_MODULE_1__.NextResponse.json({\n            message: \"error occur in Deleting Details\"\n        }, {\n            status: 500\n        });\n    }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9hcHAvYXBpL2luZGV4L1tpZF0vcm91dGUuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBdUM7QUFDSTtBQUVwQyxlQUFlRSxJQUFJQyxPQUFPLEVBQUUsRUFBRUMsTUFBTSxFQUFFO0lBQzNDLE1BQU1DLE1BQU1ELE9BQU9FLEVBQUU7SUFDckIsTUFBTUMsYUFBYSxNQUFNUCx3REFBTUEsQ0FBQ1EsR0FBRyxDQUFDO1FBQ2hDQyxPQUFPO1FBQ1BILElBQUlEO0lBQ1I7SUFDQSxPQUFPSixxREFBWUEsQ0FBQ1MsSUFBSSxDQUFDSCxXQUFXSSxPQUFPO0FBRTdDO0FBRU8sZUFBZUMsSUFBSVQsT0FBTyxFQUFFLEVBQUVDLE1BQU0sRUFBRTtJQUMzQyxJQUFJO1FBQ0EsTUFBTUMsTUFBTUQsT0FBT0UsRUFBRTtRQUNyQixNQUFNLEVBQUVPLElBQUksRUFBR0MsS0FBSyxFQUFFLEdBQUcsTUFBTVgsUUFBUU8sSUFBSTtRQUMzQyxNQUFNSyxhQUFhLE1BQU1mLHdEQUFNQSxDQUFDZ0IsTUFBTSxDQUFDO1lBQ25DUCxPQUFPO1lBQ1BILElBQUdEO1lBQ0hZLE1BQU07Z0JBQ0ZDLEtBQUk7b0JBQ0ZMO29CQUNBQztnQkFDRjtZQUNKO1FBQ0o7UUFFQSxPQUFPYixxREFBWUEsQ0FBQ1MsSUFBSSxDQUFDSztJQUM3QixFQUFFLE9BQU9JLE9BQU87UUFDWixPQUFPbEIscURBQVlBLENBQUNTLElBQUksQ0FBQztZQUFDVSxTQUFRO1FBQWlDLEdBQUU7WUFBQ0MsUUFBTztRQUFHO0lBQ3BGO0FBQ0Y7QUFDTyxlQUFlQyxPQUFPbkIsT0FBTyxFQUFHLEVBQUNDLE1BQU0sRUFBQztJQUM3QyxJQUFJO1FBQ0YsTUFBTUMsTUFBTUQsT0FBT0UsRUFBRTtRQUNyQixNQUFNaUIsYUFBYSxNQUFNdkIsd0RBQU1BLENBQUN3QixNQUFNLENBQUM7WUFDbkNmLE9BQU07WUFDTkgsSUFBR0Q7UUFDUDtRQUNBLE9BQU9KLHFEQUFZQSxDQUFDUyxJQUFJLENBQUNhO0lBQzNCLEVBQUUsT0FBT0osT0FBTztRQUNkLE9BQU9sQixxREFBWUEsQ0FBQ1MsSUFBSSxDQUFDO1lBQUNVLFNBQVE7UUFBaUMsR0FBRTtZQUFDQyxRQUFPO1FBQUc7SUFDbEY7QUFFRiIsInNvdXJjZXMiOlsid2VicGFjazovL2NydWRfMi8uL2FwcC9hcGkvaW5kZXgvW2lkXS9yb3V0ZS5qcz85NDE3Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBjbGllbnQgZnJvbSBcIkAvYXBwL2xpYi9lbGFzdGljXCI7XHJcbmltcG9ydCB7IE5leHRSZXNwb25zZSB9IGZyb20gXCJuZXh0L3NlcnZlclwiO1xyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIEdFVChyZXF1ZXN0LCB7IHBhcmFtcyB9KSB7XHJcbiAgY29uc3QgX2lkID0gcGFyYW1zLmlkO1xyXG4gIGNvbnN0IHVwZGF0ZUluZm8gPSBhd2FpdCBjbGllbnQuZ2V0KHtcclxuICAgICAgaW5kZXg6ICdjbXMtYW1hbicsXHJcbiAgICAgIGlkOiBfaWRcclxuICB9KTtcclxuICByZXR1cm4gTmV4dFJlc3BvbnNlLmpzb24odXBkYXRlSW5mby5fc291cmNlKTtcclxuXHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBQVVQocmVxdWVzdCwgeyBwYXJhbXMgfSkge1xyXG4gIHRyeSB7XHJcbiAgICAgIGNvbnN0IF9pZCA9IHBhcmFtcy5pZDtcclxuICAgICAgY29uc3QgeyBuYW1lICwgbW9ibm8gfSA9IGF3YWl0IHJlcXVlc3QuanNvbigpO1xyXG4gICAgICBjb25zdCB1cGRhdGVEYXRhID0gYXdhaXQgY2xpZW50LnVwZGF0ZSh7XHJcbiAgICAgICAgICBpbmRleDogJ2Ntcy1hbWFuJyxcclxuICAgICAgICAgIGlkOl9pZCxcclxuICAgICAgICAgIGJvZHk6IHtcclxuICAgICAgICAgICAgICBkb2M6e1xyXG4gICAgICAgICAgICAgICAgbmFtZSxcclxuICAgICAgICAgICAgICAgIG1vYm5vXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICB9KVxyXG4gICAgICBcclxuICAgICAgcmV0dXJuIE5leHRSZXNwb25zZS5qc29uKHVwZGF0ZURhdGEpXHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgICAgcmV0dXJuIE5leHRSZXNwb25zZS5qc29uKHttZXNzYWdlOlwiZXJyb3Igb2NjdXIgaW4gVXBkYXRpbmcgRGV0YWlsc1wifSx7c3RhdHVzOjUwMH0pXHJcbiAgfVxyXG59XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBERUxFVEUocmVxdWVzdCAsIHtwYXJhbXN9KXtcclxuICB0cnkge1xyXG4gICAgY29uc3QgX2lkID0gcGFyYW1zLmlkO1xyXG4gICAgY29uc3QgZGVsZXRlRGF0YSA9IGF3YWl0IGNsaWVudC5kZWxldGUoe1xyXG4gICAgICAgIGluZGV4OidjbXMtYW1hbicsXHJcbiAgICAgICAgaWQ6X2lkXHJcbiAgICB9KVxyXG4gICAgcmV0dXJuIE5leHRSZXNwb25zZS5qc29uKGRlbGV0ZURhdGEpO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICByZXR1cm4gTmV4dFJlc3BvbnNlLmpzb24oe21lc3NhZ2U6XCJlcnJvciBvY2N1ciBpbiBEZWxldGluZyBEZXRhaWxzXCJ9LHtzdGF0dXM6NTAwfSlcclxuICB9XHJcblxyXG59Il0sIm5hbWVzIjpbImNsaWVudCIsIk5leHRSZXNwb25zZSIsIkdFVCIsInJlcXVlc3QiLCJwYXJhbXMiLCJfaWQiLCJpZCIsInVwZGF0ZUluZm8iLCJnZXQiLCJpbmRleCIsImpzb24iLCJfc291cmNlIiwiUFVUIiwibmFtZSIsIm1vYm5vIiwidXBkYXRlRGF0YSIsInVwZGF0ZSIsImJvZHkiLCJkb2MiLCJlcnJvciIsIm1lc3NhZ2UiLCJzdGF0dXMiLCJERUxFVEUiLCJkZWxldGVEYXRhIiwiZGVsZXRlIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./app/api/index/[id]/route.js\n");

/***/ }),

/***/ "(rsc)/./app/lib/elastic.js":
/*!****************************!*\
  !*** ./app/lib/elastic.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _elastic_elasticsearch__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @elastic/elasticsearch */ \"(rsc)/./node_modules/@elastic/elasticsearch/index.js\");\n/* harmony import */ var _elastic_elasticsearch__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_elastic_elasticsearch__WEBPACK_IMPORTED_MODULE_0__);\n\nconst client = new _elastic_elasticsearch__WEBPACK_IMPORTED_MODULE_0__.Client({\n    node: \"http://122.180.244.93:8081\"\n});\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (client);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9hcHAvbGliL2VsYXN0aWMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQWdEO0FBRWhELE1BQU1DLFNBQVMsSUFBSUQsMERBQU1BLENBQUM7SUFDeEJFLE1BQU07QUFDUjtBQUVBLGlFQUFlRCxNQUFNQSxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY3J1ZF8yLy4vYXBwL2xpYi9lbGFzdGljLmpzPzgyZmMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ2xpZW50IH0gZnJvbSAnQGVsYXN0aWMvZWxhc3RpY3NlYXJjaCc7XHJcblxyXG5jb25zdCBjbGllbnQgPSBuZXcgQ2xpZW50KHsgXHJcbiAgbm9kZTogXCJodHRwOi8vMTIyLjE4MC4yNDQuOTM6ODA4MVwiLCBcclxufSk7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGllbnQ7Il0sIm5hbWVzIjpbIkNsaWVudCIsImNsaWVudCIsIm5vZGUiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./app/lib/elastic.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/@opentelemetry","vendor-chunks/@elastic","vendor-chunks/debug","vendor-chunks/tslib","vendor-chunks/hpagent","vendor-chunks/secure-json-parse","vendor-chunks/ms","vendor-chunks/supports-color","vendor-chunks/has-flag"], () => (__webpack_exec__("(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Findex%2F%5Bid%5D%2Froute&page=%2Fapi%2Findex%2F%5Bid%5D%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Findex%2F%5Bid%5D%2Froute.js&appDir=C%3A%5CUsers%5Camanm%5COneDrive%5CDesktop%5Ccldshp%20-%20Projects%5CCRUD-NEXTJS-ELASTIC--copy%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=C%3A%5CUsers%5Camanm%5COneDrive%5CDesktop%5Ccldshp%20-%20Projects%5CCRUD-NEXTJS-ELASTIC--copy&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!")));
module.exports = __webpack_exports__;

})();